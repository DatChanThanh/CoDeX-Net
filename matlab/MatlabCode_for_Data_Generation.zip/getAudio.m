function x = getAudio(spf,fs)
%getAudio Audio source for analog modulation types
%    A = getAudio(SPF,FS) returns an audio source, A, with
%    samples per frame, SPF, and sample rate, FS.

persistent audioSrc audioRC

if isempty(audioSrc)
    audioSrc = dsp.AudioFileReader('audio_mix_441.wav',...
        'SamplesPerFrame',spf,'PlayCount',inf);
    audioRC = dsp.SampleRateConverter('Bandwidth',30e3,...
        'InputSampleRate',audioSrc.SampleRate,...
        'OutputSampleRate',fs);
    [~,decimFactor] = getRateChangeFactors(audioRC);
    audioSrc.SamplesPerFrame = ceil(spf / fs * audioSrc.SampleRate / decimFactor) * decimFactor;
end

x = audioRC(audioSrc());
x = x(1:spf,1);
end