function src = getSource(modType, sps, spf, fs)
%getSource Source selector for modulation types
%    SRC=getSource(TYPE,SPS,SPF,FS) returns the data source
%    for modulation type, TYPE, with samples per symbol, SPS,
%    samples per frame, SPF, and sampling frequency, FS.

switch modType
    case {"BPSK","GFSK","CPFSK"}
        M = 2;
        src = @()randi([0 M-1],spf/sps,1);
    case {"QPSK","PAM4"}
        M = 4;
        src = @()randi([0 M-1],spf/sps,1);
    case {"B-FM","DSB-AM","SSB-AM"}
        src = @()getAudio(spf,fs);
    case "16-QAM"
        M = 16;
        src = @()randi([0 M-1],spf/sps,1);

end
end