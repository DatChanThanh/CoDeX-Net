function y = bfmModulator(x,fs)
%bfmModulator Broadcast FM modulator
%   Y=bfmModulator(X,FS) broadcast FM modulates input, X, and returns 
%   signal, Y, at a sample rate of FS. X must be a column vector of 
%   audio samples at sample rate of FS. Frequency deviation is 75 kHz 
%   and pre-emphasis filter time constant is 75 microseconds. 

persistent mod
if isempty(mod)
  mod = comm.FMBroadcastModulator(...
    'AudioSampleRate', fs, ...
    'SampleRate', fs);
end
y = mod(x);
end