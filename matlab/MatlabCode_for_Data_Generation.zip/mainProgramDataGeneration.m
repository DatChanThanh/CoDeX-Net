%% Commnunication Signal Generation
clear
numFramesPerModType = 4000; % number of signals generated for each type of waveform
sps = 8;                % Samples per symbol
spf = 1024;             % Samples per frame
fs = 200e3;             % Sampling rate

channel = helperModClassTestChannel(...
  'SampleRate', fs, ...
  'PathDelays', [0 30 150 310 370 710 1090]* 1e-9, ...
  'AveragePathGains', [0 -1.5 -1.4 -3.6 -0.6 -9.1 -7.0], ...
  'KFactor', 4, ...
  'MaximumDopplerShift', 0, ...
  'MaximumClockOffset', 5, ...
  'CenterFrequency', 900e6);

modulationTypes = {'BPSK','QPSK','GFSK','CPFSK','PAM4','16-QAM','B-FM','DSB-AM'};
dopplerSet = [0 4 70 300];

folderImg= 'racomDataset12class';
snr = -5:5:30;
imgsize = 224;
filter = kaiser(101,20);
numModulationTypes = length(modulationTypes);
transDelay = 25;


for iM = 1 : numModulationTypes
    modType = modulationTypes{iM};
    disp(['Generating ',modType,'....'])
    mkdir(fullfile(folderImg,modType));
    dataSrc = getSource(modulationTypes{iM}, sps, 2*spf, fs);
    modulator = getModulator(modulationTypes{iM}, sps, fs);
    
    if contains(char(modulationTypes{iM}), {'B-FM','DSB-AM'})
    channel.CenterFrequency = 100e6;
    else
    channel.CenterFrequency = 900e6;
    end 
    
    for idxsnr = 1 : length(snr)
        fprintf('SNR = %d\n',snr(idxsnr))
        channel.SNR = snr(idxsnr); 
        for iS = 1 : numFramesPerModType
            x = dataSrc();
            y = modulator(x);
            dopplerValue = dopplerSet(randi(length(dopplerSet))); 
            release(channel);
            channel.MaximumDopplerShift = dopplerValue;
            rxSamples = channel(y);
            wav = helperModClassFrameGenerator(rxSamples, spf, spf, transDelay, sps);
            TFD = wvd(wav,fs,'smoothedPseudo',filter,filter,'NumFrequencyPoints',imgsize,'NumTimePoints',imgsize);
            TFD = rescale(TFD);
            filenamImg = fullfile(folderImg, modType, sprintf('signal_snr%02d_doppler%03d_img%05d.png',idxsnr,dopplerValue,iS));
            imwrite(TFD,filenamImg)
        end
    end

end

%% Radar Signals Generation
clear
% --- 1. Centralized Setup ---
Fs = 1e8; 
nSignalsPerMod = 4000; 
Ts = 1/Fs; 
rng(0)

% Channel and processing objects
channel = comm.RicianChannel(...
    'SampleRate', Fs, ...
    'PathDelays', [0 30 150 310 370 710 1090]* 1e-9, ...
    'AveragePathGains', [0 -1.5 -1.4 -3.6 -0.6 -9.1 -7.0], ...
    'KFactor', 4, ...
    'MaximumDopplerShift', 0); % MaximumDopplerShift is tunable for RicianChannel
hFreqOffset = comm.PhaseFrequencyOffset('SampleRate',Fs);

% Generation parameters
modTypes = {'LFM','Rect','Barker','StepFM'};
dopplerSet = [0 4 70 300];
folderImg= 'racomDataset12class';
imgsize = 224;
snr = -5 : 5 : 30;
filter = kaiser(101,20);

% Waveform parameter ranges
rangeFc = [Fs/6, Fs/5];
rangeN = [512, 1920];
rangeB = [Fs/20, Fs/16];
sweepDirections = {'Up','Down'};
rangeNChip = [3,4,5,7,11];
rangeNcc = [1,5];
rangeStep = [3,4,5,7,11];

% --- 2. Main Generation Loop ---
for iM = 1:length(modTypes)
    modType = modTypes{iM};
    disp(['Generating ', modType, '....'])
    mkdir(fullfile(folderImg, modType));

    % Initialize the specific waveform generator once
    hWav = [];
    switch modType
        case 'Rect'
            hWav = phased.RectangularWaveform('SampleRate',Fs,'OutputFormat','Samples');
        case 'LFM'
            hWav = phased.LinearFMWaveform('SampleRate',Fs,'OutputFormat','Samples');
        case 'Barker'
            hWav = phased.PhaseCodedWaveform('SampleRate',Fs,'OutputFormat','Samples','Code','Barker');
        case 'StepFM'
            hWav = phased.SteppedFMWaveform('SampleRate',Fs,'OutputFormat','Samples');
    end

    for idxsnr = 1:length(snr)
        SNR = snr(idxsnr);
        fprintf('SNR = %d\n', SNR);

        for iS = 1:nSignalsPerMod
            % THE FIX: Release the waveform object to allow property changes
            release(hWav); 

            % --- Unique Waveform Generation ---
            Fc = randOverInterval(rangeFc);
            switch modType
                case 'Rect'
                    Ncc = round(randOverInterval(rangeN));
                    hWav.PulseWidth = Ncc*Ts;
                    hWav.PRF = 1/(Ncc*Ts);
                    hWav.NumSamples = 1024;
                case 'LFM'
                    B = randOverInterval(rangeB);
                    Ncc = round(randOverInterval(rangeN));
                    hWav.SweepBandwidth = B;
                    hWav.PulseWidth = Ncc*Ts;
                    hWav.NumSamples = 1024;
                    hWav.PRF = 1/(Ncc*Ts);
                    hWav.SweepDirection = sweepDirections{randi(2)};
                case 'Barker'
                    N = rangeNChip(randi(length(rangeNChip)));
                    Ncc_val = rangeNcc(randi(length(rangeNcc)));
                    chipWidthSamples = round(Ncc_val/Fc*Fs)-1;
                    hWav.ChipWidth = chipWidthSamples*Ts;
                    hWav.NumChips = N;
                    hWav.PRF = 1/((chipWidthSamples*N+1)*Ts);
                    hWav.NumSamples = 1024;
                case 'StepFM'
                    Ncc = round(randOverInterval([512, 1024]));
                    hWav.PulseWidth = Ncc*Ts;
                    hWav.NumSamples = 1024;
                    hWav.PRF = 1/((Ncc+randi([50,100]))*Ts);
                    hWav.NumSteps = rangeStep(randi(length(rangeStep)));
                    hWav.FrequencyStep = randi(5)*hWav.PRF;
            end
            wav = step(hWav);

            % --- 4. Common Processing and Saving Block (Corrected) ---
            wav = awgn(wav, SNR);
            
            hFreqOffset.FrequencyOffset = Fc/10;
            wav = step(hFreqOffset, wav);
            
            dopplerValue = dopplerSet(randi(length(dopplerSet)));
            
            % THE FIX: Release the channel object before changing its property
            release(channel); 
            channel.MaximumDopplerShift = dopplerValue;
            wav = step(channel, wav);
            
            TFD = wvd(wav, Fs, 'smoothedPseudo', filter, filter, 'NumFrequencyPoints', imgsize, 'NumTimePoints', imgsize);
            TFD = rescale(TFD);
            filenamImg = fullfile(folderImg, modType, sprintf('signal_snr%02d_doppler%03d_img%05d.png', idxsnr, dopplerValue, iS));
            imwrite(TFD, filenamImg);
        end
    end
    release(hWav); % Release waveform generator after use
end

disp('Data generation complete.');
% Helper function used in the script
function val = randOverInterval(interval)
    val = (interval(2) - interval(1)).*rand + interval(1);
end