function y = qpskModulator(x,sps)
%qpskModulator QPSK modulator with pulse shaping
%   Y=qpskModulator(X,SPS) QPSK modulates input, X, and returns a root-raised
%   cosine pulse shaped signal, Y. X must be a column vector of values in
%   the set of [0 3]. Root-raised cosine filter has a roll-off factor of
%   0.35 and spans four symbols. The output signal, Y, has unit power.

persistent filterCoeffs
if isempty(filterCoeffs)
  filterCoeffs = rcosdesign(0.35, 4, sps);
end
% Modulate
syms = pskmod(x,4,pi/4);
% Pulse shape
y = filter(filterCoeffs, 1, upsample(syms,sps));
end
