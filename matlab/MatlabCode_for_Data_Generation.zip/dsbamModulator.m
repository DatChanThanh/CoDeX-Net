function y = dsbamModulator(x,fs)
%dsbamModulator Double sideband AM modulator
%   Y=dsbamModulator(X,FS) double sideband AM modulates input, X, and 
%   returns signal, Y, at a sample rate of FS. X must be a column vector of 
%   audio samples at sample rate of FS. IF frequency is 50 kHz. 

y = ammod(x,50e3,fs);
end
