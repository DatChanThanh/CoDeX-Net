function modulator = getModulator(modType, sps, fs)
%getModulator Modulation function selector
%   MOD = getModulator(TYPE,SPS,FS) returns a modulator function handle,
%   MOD, based on the TYPE. SPS is samples per symbol and FS is sampling
%   rate.

switch modType
    case "BPSK"
        modulator = @(x)bpskModulator(x,sps);
    case "QPSK"
        modulator = @(x)qpskModulator(x,sps);
    case "GFSK"
        modulator = @(x)gfskModulator(x,sps);
    case "CPFSK"
        modulator = @(x)cpfskModulator(x,sps);
    case "PAM4"
        modulator = @(x)pam4Modulator(x,sps);
    case "B-FM"
        modulator = @(x)bfmModulator(x, fs);
    case "DSB-AM"
        modulator = @(x)dsbamModulator(x, fs);
    case "SSB-AM"
        modulator = @(x)ssbamModulator(x, fs);
    case "16-QAM"
        modulator = @(x)qam16Modulator(x,sps);
end
end