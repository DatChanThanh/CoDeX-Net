function y = cpfskModulator(x,sps)
%cpfskModulator CPFSK modulator
%   Y=cpfskModulator(X,SPS) CPFSK modulates input, X, and returns signal, Y. 
%   X must be a column vector of values in the set of [0 1]. Modulation 
%   index is 0.5. The output signal, Y, has unit power.

persistent mod meanM
if isempty(mod)
  M = 2;
  mod = comm.CPFSKModulator(...
    'ModulationOrder', M, ...
    'ModulationIndex', 0.5, ...
    'SamplesPerSymbol', sps);
  meanM = mean(0:M-1);
end
% Modulate
y = mod(2*(x-meanM));
end