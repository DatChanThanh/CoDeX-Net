function y = qam16Modulator(x,sps)
%qam16Modulator 16-QAM modulator with pulse shaping
%   Y=qam16Modulator(X,SPS) 16-QAM modulates input, X, and returns a 
%   root-raised cosine pulse shaped signal, Y. X must be a column vector 
%   of values in the set of [0 15]. Root-raised cosine filter has a 
%   roll-off factor of 0.35 and spans four symbols. The output signal, Y, 
%   has unit power.

persistent filterCoeffs amp
if isempty(filterCoeffs)
  filterCoeffs = rcosdesign(0.35, 4, sps);
  amp = 1 / sqrt(mean(abs(qammod(0:15, 16)).^2));
end
% Modulate
syms = amp * qammod(x,16);
% Pulse shape
y = filter(filterCoeffs, 1, upsample(syms,sps));
end